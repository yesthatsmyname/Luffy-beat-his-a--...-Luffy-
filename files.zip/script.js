"use strict";
/* ---------- DATA ---------- */
// stats order: Strength, Speed, Durability, Combat Skill, Special Abilities, Overall
const STAT_NAMES = ["Strength","Speed","Durability","Combat Skill","Special Abilities","Overall Power"];
const FIGHTERS = {
  N:{ name:"Naruto Uzumaki", title:"The Seventh Hokage · Hero of the Hidden Leaf", color:"#ff9d1c",
    personality:"Loud, stubborn and endlessly optimistic. A lonely orphan who became a village hero by refusing to give up and by befriending even his enemies.",
    style:"Shinobi all-rounder: shadow clone swarms, close-range taijutsu, and huge chakra reserves used for ninjutsu and sage techniques.",
    attacks:["Rasengan","Rasenshuriken","Shadow Clone Jutsu","Tailed Beast Bomb","Planetary Rasengan","Massive Rasenshuriken"],
    metric:"Chakra",
    forms:[
      {n:"Base Naruto", s:[55,60,55,65,60,58], c:"#ff9d1c", hair:"#ffd34d", info:"Fights with clones and Rasengan. Clever and unpredictable.", m:"High", extra:"Kurama’s chakra lingers beneath the surface."},
      {n:"Sage Mode", s:[65,75,68,75,78,72], c:"#ff7a1a", hair:"#ffd34d", info:"Natural energy boosts senses and power; toad-style Frog Kata extends strikes.", m:"Very high + nature energy", extra:"Sage Art: Rasenshuriken, Giant Rasengan."},
      {n:"Kurama Chakra Mode", s:[80,88,80,80,85,83], c:"#ffc400", hair:"#ffe14d", info:"Golden cloak shared with Kurama: huge speed, chakra arms and tailed-beast bombs.", m:"Enormous", extra:"Senses emotions and sends chakra arms."},
      {n:"Six Paths Sage Mode", s:[92,95,90,88,95,92], c:"#fff3b0", hair:"#fff6b0", info:"Gifted by the Sage of Six Paths. Truth-Seeking Orbs, flight and powerful senjutsu.", m:"Near limitless", extra:"Truth-Seeking Balls, Six Paths Rasenshuriken."},
      {n:"Baryon Mode", s:[96,98,70,90,97,96], c:"#ffb300", hair:"#ffcc33", info:"Last-resort form burning life force with Kurama. Overwhelming speed and power with a fatal cost.", m:"Burning life force", extra:"Chakra cloak burns his lifespan. Heat can melt the landscape."}
    ]},
  L:{ name:"Monkey D. Luffy", title:"Straw Hat Captain · Warrior of Liberation", color:"#ff2e3d",
    personality:"Carefree, fiercely loyal and hungry. Dreams of freedom and becoming King of the Pirates, and he will fight anyone to protect his crew.",
    style:"Rubber-body brawler: stretchy punches, Haki-coated strikes, and bursts of power from Gear techniques.",
    attacks:["Gomu Gomu no Pistol","Gum-Gum Gatling","Red Hawk","Elephant Gun","Bajrang Gun","Dawn Rocket"],
    metric:"Haki",
    forms:[
      {n:"Base Luffy", s:[50,52,60,62,45,53], c:"#ff2e3d", hair:"#1a1a22", info:"Rubber body shrugs off blunt force. Fights with Gum-Gum techniques and instinct.", m:"Advanced Armament, Observation", extra:"Rubber immunity to blunt and electric attacks."},
      {n:"Gear 2", s:[58,70,62,68,50,62], c:"#ff6b8a", hair:"#1a1a22", info:"Pumps blood to boost speed and reflexes. Steam rises from his body.", m:"Armament + Observation", extra:"Jet-style combos, faster reactions."},
      {n:"Gear 3", s:[72,66,72,72,60,69], c:"#ff4a2a", hair:"#1a1a22", info:"Inflates a limb with air for gigantic strikes. Powerful but slows him afterward.", m:"Armament coated", extra:"Gigantic fist, Elephant Gun."},
      {n:"Gear 4", s:[86,84,86,85,72,83], c:"#c8102e", hair:"#1a1a22", info:"Muscle-inflated Boundman, Tankman and Snakeman forms coated in Haki. Rebound-powered strikes.", m:"Strong Armament, Observation", extra:"Boundman, Tankman, Snakeman."},
      {n:"Gear 5", s:[95,92,94,96,98,94], c:"#ffffff", hair:"#ffffff", info:"Awakened Devil Fruit: Sun God Nika. Cartoon physics, reality-bending rubber and relentless joy.", m:"Awakened Armament + Observation", extra:"Turns the world rubbery, huge Haki."}
    ]}
};
const state = {N:0, L:0};
const $ = id => document.getElementById(id);

/* ---------- PORTRAITS ---------- */
const IMG={N:"images/naruto-base.webp",L:"images/luffy-base.png"};
const CUT={N:{1:1,3:1,4:1},L:{2:1,3:1}}; // forms whose picture is a transparent cutout (glow instead of frame)
const FORMIMG={N:{1:"images/naruto-sage-mode.webp",2:"images/naruto-kurama-chakra-mode.webp",3:"images/naruto-six-paths-sage-mode.webp",4:"images/naruto-baryon-mode.webp"},L:{2:"images/luffy-gear-3.png",3:"images/luffy-gear-4.png",4:"images/luffy-gear-5.webp",1:"images/luffy-gear-2.webp"}}; // per-form pictures, keyed by form index
// Per-form glow filters applied over the uploaded pictures.
const FX={N:["","sepia(.3) saturate(1.4) drop-shadow(0 0 14px #ff7a1a)","saturate(1.5) brightness(1.15) drop-shadow(0 0 22px #ffc400) drop-shadow(0 0 40px #ffc400)","brightness(1.4) saturate(.7) drop-shadow(0 0 25px #fff3b0) drop-shadow(0 0 50px #fff)","brightness(1.2) saturate(1.8) drop-shadow(0 0 25px #ffb300) drop-shadow(0 0 55px #ff6a00)"],
L:["","saturate(1.3) drop-shadow(0 0 16px #ff6b8a)","saturate(1.4) contrast(1.1) drop-shadow(0 0 22px #ff4a2a)","contrast(1.3) brightness(.65) saturate(1.2) drop-shadow(0 0 25px #c8102e)","brightness(1.5) saturate(.5) drop-shadow(0 0 25px #fff) drop-shadow(0 0 50px #fff)"]};
// Build the picture for a fighter: aura behind + form-coloured glow filter.
function portrait(who, f){
  // A form with its own picture (FORMIMG) shows it as a framed scene; others reuse the base cutout with a glow filter.
  const own = FORMIMG[who][state[who]];
  if(own && CUT[who][state[who]]) return `<div class="stage" style="background:radial-gradient(closest-side,${f.c}77,transparent 92%)"><img src="${own}" alt="${FIGHTERS[who].name} – ${f.n}" style="filter:drop-shadow(0 0 18px ${f.c}) drop-shadow(0 0 40px ${f.c})"></div>`;
  if(own) return `<div class="stage"><img class="scene" src="${own}" alt="${FIGHTERS[who].name} – ${f.n}" style="box-shadow:0 0 35px ${f.c},0 0 70px ${f.c}88;border-color:${f.c}"></div>`;
  return `<div class="stage" style="background:radial-gradient(closest-side,${f.c}77,transparent 92%)"><img src="${IMG[who]}" alt="${FIGHTERS[who].name} – ${f.n}" style="filter:${FX[who][state[who]]||"drop-shadow(0 0 14px "+f.c+")"}"></div>`;
}

/* ---------- RENDER ---------- */
// Redraw one fighter: portrait, form name, glow colour; then update bars.
function renderFighter(who, animate){
  const f = FIGHTERS[who].forms[state[who]];
  const box = $("f"+who);
  box.style.setProperty("--glow", f.c);
  $("p"+who).innerHTML = portrait(who, f);
  $("n"+who).textContent = f.n.toUpperCase();
  if(animate){ box.classList.remove("swap"); void box.offsetWidth; box.classList.add("swap"); }
  renderBars();
}

// Build the comparison rows once, then animate widths on each update.
function renderBars(){
  const n = FIGHTERS.N.forms[state.N].s, l = FIGHTERS.L.forms[state.L].s;
  const box = $("bars");
  if(!box.children.length){
    box.innerHTML = STAT_NAMES.map((s,i)=>`<div class="row"><div class="track"><div class="fill" id="nb${i}" style="background:linear-gradient(90deg,#ff6a00,#ffd34d);margin-left:auto"><i style="left:6px"></i></div></div><span class="l">${s}</span><div class="track"><div class="fill" id="lb${i}" style="background:linear-gradient(90deg,#ff2e3d,#ff8a5c)"><i style="right:6px"></i></div></div></div>`).join("");
  }
  STAT_NAMES.forEach((_,i)=>{
    [["nb",n[i]],["lb",l[i]]].forEach(([p,v])=>{
      const e=$(p+i); e.style.width=v+"%"; e.firstChild.textContent=v;
    });
  });
}

/* ---------- INFO PANELS ---------- */
// Open the stylish profile panel for the clicked fighter and current form.
function showInfo(who){
  const d = FIGHTERS[who], f = d.forms[state[who]];
  const bars = ["Speed","Strength","Durability"].map(k=>{
    const v = f.s[STAT_NAMES.indexOf(k)]; return `<div style="margin:4px 0">${k}: <b>${v}</b><div class="track"><div class="fill" style="width:${v}%;background:${d.color}"></div></div></div>`;}).join("");
  $("infoBox").style.setProperty("--c", f.c==="#ffffff"?"#ffe9b0":f.c);
  $("infoBox").innerHTML = `<button class="btn x" id="cl" style="--c:#fff">✕</button>
  <h3>${d.name}</h3><div style="color:var(--mut)">${d.title}</div>
  <h4>PERSONALITY &amp; BACKGROUND</h4><div>${d.personality}</div>
  <h4>ABILITIES &amp; FIGHTING STYLE</h4><div>${d.style}</div>
  <h4>STRONGEST ATTACKS</h4><div class="chips">${d.attacks.map(a=>`<span>${a}</span>`).join("")}</div>
  <h4>CURRENT FORM: ${f.n.toUpperCase()}</h4><div>${f.info}<br><i>${f.extra}</i></div>
  <h4>POWER STATS</h4>${bars}<div>${d.metric}: <b>${f.m}</b></div>
  <h4>ALL TRANSFORMATIONS</h4><div class="chips">${d.forms.map(x=>`<span>${x.n}</span>`).join("")}</div>`;
  $("info").classList.add("on");
  $("cl").onclick = ()=>$("info").classList.remove("on");
}

/* ---------- FORM SWITCHING ---------- */
// Cycle to the fighter's next form and animate the transformation.
function switchForm(who){
  state[who] = (state[who]+1) % FIGHTERS[who].forms.length;
  renderFighter(who, true);
}

/* ---------- BATTLE ---------- */
// Show form selection so the user picks which versions fight.
function openBattle(){
  const opts = w => FIGHTERS[w].forms.map((f,i)=>`<option value="${i}" ${i===state[w]?"selected":""}>${f.n}</option>`).join("");
  $("battleBox").innerHTML = `<button class="btn x" id="bc" style="--c:#fff">✕</button><h3>CHOOSE YOUR FIGHTERS’ FORMS</h3>
  <div class="sel"><label style="color:#ff9d1c">Naruto<select id="selN">${opts("N")}</select></label><label style="color:#ff2e3d">Luffy<select id="selL">${opts("L")}</select></label></div>
  <div class="ctr"><button class="btn win" id="fight">FIGHT!</button></div>`;
  $("battle").classList.add("on");
  $("bc").onclick = ()=>$("battle").classList.remove("on");
  $("fight").onclick = runFight;
}

// Play the explosion animation, then reveal the result.
function runFight(){
  const nI = +$("selN").value, lI = +$("selL").value;
  state.N = nI; state.L = lI; renderFighter("N",true); renderFighter("L",true);
  $("battle").classList.remove("on");
  const boom = $("boom"); boom.style.display="block"; boom.style.animation="none"; void boom.offsetWidth; boom.style.animation="";
  document.body.classList.add("shake");
  setTimeout(()=>{ document.body.classList.remove("shake"); boom.style.display="none"; showResult(nI,lI); }, 1800);
}

// Decide the winner from overall power (ties go to special abilities), and write the reason.
function showResult(nI,lI){
  const n = FIGHTERS.N.forms[nI], l = FIGHTERS.L.forms[lI];
  const ns=n.s, ls=l.s;
  let nw = ns[5]!==ls[5] ? ns[5]>ls[5] : ns[4]>=ls[4];
  const w = nw?n:l, lo = nw?l:n, ws = nw?ns:ls, los = nw?ls:ns;
  const wn = nw?"NARUTO":"LUFFY", gap = Math.abs(ns[5]-ls[5]);
  // best category where the winner leads
  let best=0; ws.slice(0,5).forEach((v,i)=>{ if(v-los[i] > ws[best]-los[best]) best=i; });
  const edge = gap<=2 ? "A razor-thin fight decided by who lands the final special move." : gap<=10 ? "A hard-fought, back-and-forth battle." : "An overwhelming, one-sided clash.";
  const reason = `${edge} ${nw?"Naruto’s":"Luffy’s"} ${w.n} leads in ${STAT_NAMES[best].toLowerCase()} (${ws[best]} vs ${los[best]}). ${w.extra} Against ${lo.n}, that decides the fight.`;
  const col = nw?"#ff9d1c":"#ff2e3d";
  $("battleBox").style.setProperty("--c", col);
  $("battleBox").innerHTML = `<div class="ctr"><div style="color:var(--mut)">${n.n} vs ${l.n}</div>
  <div class="winner" style="color:${col};text-shadow:0 0 20px ${col}">🏆 ${wn} WINS!</div>
  <div style="margin:10px 0">${reason}</div>
  <div class="note">Fan-made estimate: the result changes with forms, feats and canon.</div>
  <button class="btn" id="re" style="--c:#ffd34d">REMATCH</button><button class="btn" id="bc" style="--c:#fff">CLOSE</button></div>`;
  $("battle").classList.add("on");
  $("re").onclick = openBattle;
  $("bc").onclick = ()=>$("battle").classList.remove("on");
}

/* ---------- EVENTS ---------- */
$("pN").onclick = ()=>showInfo("N");
$("pL").onclick = ()=>showInfo("L");
$("sN").onclick = ()=>switchForm("N");
$("sL").onclick = ()=>switchForm("L");
$("go").onclick = openBattle;
document.addEventListener("keydown", e=>{ if(e.key==="Escape"){ $("info").classList.remove("on"); $("battle").classList.remove("on"); }});
[$("info"),$("battle")].forEach(o=>o.addEventListener("click",e=>{ if(e.target===o) o.classList.remove("on"); }));
renderFighter("N"); renderFighter("L");
